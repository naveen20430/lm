<footer class="main"
	style="text-align: center;">
	Need help?  <a href="" target="_blank" style="text-decoration:underline;">Contact support</a>
</footer>
