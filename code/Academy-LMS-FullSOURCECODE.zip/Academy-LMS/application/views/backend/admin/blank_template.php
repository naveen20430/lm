<ul class="breadcrumb">
  <li><a href="#" class="">Sliders</a> </li>
  <li><a href="#" class="">Sliders</a> </li>
  <li><a href="#" class="active">Blank Template</a> </li>
</ul>
<div class="page-title"> <i class="icon-custom-left"></i>
  <h3>Simple - <span class="semi-bold">Sliders</span></h3>
</div>
<div class="row">
  <div class="col-md-12">
    <div class="grid simple">
      <div class="grid-title no-border">
        <h4>Basic <span class="semi-bold">Sliders</span></h4>
      </div>
      <div class="grid-body no-border">
        <div class="row">
            <h1>Lets make sure that it works perfectly</h1>
        </div>
      </div>
    </div>
  </div>
</div>

<div class="row">
    <div class="col-md-12">
      <div class="grid simple">
        <div class="grid-title no-border">
          <h4>Basic <span class="semi-bold">Sliders</span></h4>
        </div>
        <div class="grid-body no-border">
          <div class="row">
              <h1>Lets make sure that it works perfectly. I know it will work perfectly</h1>
          </div>
        </div>
      </div>
    </div>
</div>
