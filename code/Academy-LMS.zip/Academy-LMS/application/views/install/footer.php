<footer class="main"
	style="text-align: center;">
	
</footer>
